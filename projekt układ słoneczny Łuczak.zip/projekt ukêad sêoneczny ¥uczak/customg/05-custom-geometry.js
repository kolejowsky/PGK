// once everything is loaded, we run our Three.js stuff.
window.onload = function () {

    // create a scene, that will hold all our elements such as objects, cameras and lights.
    const scene = new THREE.Scene();

    // create a camera, which defines where we're looking at.
    const camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 0.1, 1000 );

    // create a render and set the size
    const renderer = new THREE.WebGLRenderer();

    renderer.setClearColor( new THREE.Color(0xdddddd) );
    renderer.setSize( window.innerWidth, window.innerHeight) ;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // add OrbitControls
    const controls = new THREE.OrbitControls( camera, renderer.domElement );

    // add the output of the renderer to the html element
    document.getElementById( "WebGL-output" ).appendChild( renderer.domElement );

    // create the ground plane
    const planeGeometry = new THREE.PlaneGeometry( 60, 40, 1, 1 );
    //const planeMaterial = new THREE.MeshLambertMaterial( {color: 0x5555ff, transparent: true, opacity: 0.8, side: THREE.DoubleSide} );
    const planeMaterial = new THREE.MeshStandardMaterial( {color: 0x5555ff, transparent: true, opacity: 0.8, side: THREE.DoubleSide, roughness: 1.0, metalness: 0.0} );
    const plane = new THREE.Mesh( planeGeometry, planeMaterial );
    plane.receiveShadow = true;

    // rotate and position the plane
    plane.rotation.x = -0.5 * Math.PI;
    plane.position.x = 0.0;
    plane.position.y = -1.0;
    plane.position.z = 0.0;

    // add the plane to the scene
    scene.add(plane);

    // position and point the camera to the center of the scene
    camera.position.x = -20.0;
    camera.position.y = 25.0;
    camera.position.z = 20.0;
    const cameraLookAtPosition = new THREE.Vector3( 5.0, 0.0, 0.0 );
    camera.lookAt( cameraLookAtPosition );
    controls.target.copy( cameraLookAtPosition );
    controls.update();

    // add subtle ambient lighting
    const ambientLight = new THREE.AmbientLight( 0x494949 );
    scene.add( ambientLight );

    // add spotlight for the shadows
    const spotLight = new THREE.SpotLight( 0xffffff );
    spotLight.position.set( -40, 30, 10 );
    spotLight.castShadow = true;
    scene.add( spotLight );


    const geometry = new THREE.BufferGeometry();

    const vertices = new Float32Array( [
       1.0,  3.0,  1.0,
       1.0, -1.0,  1.0,
       1.0,  3.0, -1.0,

       1.0, -1.0,  1.0,
       1.0, -1.0, -1.0,
       1.0,  3.0, -1.0,

      -1.0,  3.0, -1.0,
      -1.0, -1.0, -1.0,
      -1.0,  3.0,  1.0,

      -1.0, -1.0, -1.0,
      -1.0, -1.0,  1.0,
      -1.0,  3.0,  1.0,

      -1.0,  3.0, -1.0,
      -1.0,  3.0,  1.0,
       1.0,  3.0, -1.0,

      -1.0,  3.0,  1.0,
       1.0,  3.0,  1.0,
       1.0,  3.0, -1.0,

      -1.0, -1.0,  1.0,
      -1.0, -1.0, -1.0,
       1.0, -1.0,  1.0,

      -1.0, -1.0, -1.0,
       1.0, -1.0, -1.0,
       1.0, -1.0,  1.0,

      -1.0,  3.0,  1.0,
      -1.0, -1.0,  1.0,
       1.0,  3.0,  1.0,

      -1.0, -1.0,  1.0,
       1.0, -1.0,  1.0,
       1.0,  3.0,  1.0,

       1.0,  3.0, -1.0,
       1.0, -1.0, -1.0,
      -1.0,  3.0, -1.0,

       1.0, -1.0, -1.0,
      -1.0, -1.0, -1.0,
      -1.0,  3.0, -1.0
    ] );

    geometry.setAttribute( 'position', new THREE.BufferAttribute( vertices, 3 ) );
    geometry.computeBoundingSphere();

    const materials = [
        new THREE.MeshLambertMaterial( {opacity: 0.6, color: 0x44ff44, transparent: true} ),
        new THREE.MeshBasicMaterial( {color: 0x00ff00, wireframe: true} )
    ];

    const mesh = new THREE.Group( geometry, materials );
    materials.forEach( function ( e ) {
        mesh.add(new THREE.Mesh( geometry, e ));
    });
    mesh.children.forEach( function ( e ) {
        e.castShadow = true;
    });

    scene.add( mesh );

    function animate() {

            requestAnimationFrame( animate );

            mesh.children.forEach( function ( e ) {
                e.geometry.vertices = vertices;
                e.geometry.verticesNeedUpdate = true;
                e.geometry.computeVertexNormals();
            });

            controls.update();

            renderer.render( scene, camera );
    }

    animate();

    // redraw in case of window's size change
    window.addEventListener(
      'resize',
      function() {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize( window.innerWidth, window.innerHeight );
        renderer.render( scene, camera );
      },
      false
    );

}
