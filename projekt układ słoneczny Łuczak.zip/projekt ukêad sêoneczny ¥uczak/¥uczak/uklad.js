
const renderer = new THREE.WebGLRenderer();
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap; // default THREE.PCFShadowMap
			renderer.setSize( window.innerWidth, window.innerHeight );
			document.body.appendChild( renderer.domElement );
	

const scene = new THREE.Scene();
//scene.background = new THREE.Color( 0x222222 );
scene.background = new THREE.TextureLoader().load("./img/2k_stars.jpg");
const camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 0.1, 10000 );

const controls = new THREE.OrbitControls( camera, renderer.domElement );	

camera.position.set( 1000, 2000, 0 );

controls.update();
//tło 
const skyBoxGeo = new THREE.SphereGeometry( 5000, 64, 32 );
const skyBoxMat = new THREE.MeshBasicMaterial( {map: new THREE.TextureLoader().load("./img/2k_stars2.jpg") , side: THREE.DoubleSide }  );
const skyBox = new THREE.Mesh( skyBoxGeo, skyBoxMat );
scene.add( skyBox );


const Light = new THREE.PointLight( 0xffffff, 1, 3000 );
Light.position.set( 0, 0, 0 );
Light.castShadow = true;
scene.add( Light );
const Light2 = new THREE.AmbientLight( 0x888888 );
scene.add( Light2 );

//slonce
const sunGeo = new THREE.SphereGeometry( 200, 64, 32 );
const sunMat = new THREE.MeshBasicMaterial( { map: new THREE.TextureLoader().load("./img/2k_sun.jpg") } );
const sun = new THREE.Mesh( sunGeo, sunMat );

//merkury sama planeta
const mercuryGeo = new THREE.SphereGeometry( 2, 64, 32 );
const mercuryMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_mercury.jpg") } );
const mercury = new THREE.Mesh( mercuryGeo, mercuryMat );
//rzucanie cienia
mercury.castShadow = true;
//łapanie cienia
mercury.receiveShadow = true;

mercury.position.x = 270;
//odleglosc od powierzchni slonca 70

//grupa z merkurym
const mercuryGroup = new THREE.Group();
mercuryGroup.add( mercury );

mercuryGroup.rotation.x=0.35;

//wenus sama planeta
const venusGeo = new THREE.SphereGeometry( 6, 64, 32 );
const venusMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_venus.jpg")} );
const venus = new THREE.Mesh( venusGeo, venusMat );

venus.castShadow = true;
venus.receiveShadow = true;

venus.position.x = 340;
//odleglosc od powierzchni slonca 140

//grupa z wenus
const venusGroup = new THREE.Group();
venusGroup.add( venus );

venusGroup.rotation.x=-0.5;

//ziemia sama planeta
const earthGeo = new THREE.SphereGeometry( 7, 64, 32 );
const earthMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_earth_daymap.jpg")} );
const earth = new THREE.Mesh( earthGeo, earthMat );

earth.castShadow = true;
earth.receiveShadow = true;

//ksiezyc
const moonGeo = new THREE.SphereGeometry( 1, 64, 32 );
const moonMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_moon.jpg")} );
const moon = new THREE.Mesh( moonGeo, moonMat );

moon.castShadow = true;
moon.receiveShadow = true;

moon.position.z = 9;

//ksiezyc i ziemia
const earthMoon = new THREE.Group();
earthMoon.add( earth );
earthMoon.add( moon );
earthMoon.position.x = 410;
//odleglosc od powierzchni slonca 210

//grupa z ziemia i ksiezycem
const earthMoonGroup = new THREE.Group();
earthMoonGroup.add( earthMoon );
earthMoonGroup.rotation.x=0.5;

//mars sama planeta
const marsGeo = new THREE.SphereGeometry( 3, 64, 32 );
const marsMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_mars.jpg")} );
const mars = new THREE.Mesh( marsGeo, marsMat );

mars.castShadow = true;
mars.receiveShadow = true;

mars.position.x = 550;
//odleglosc od powierzchni slonca 350

//grupa z marsem
const marsGroup = new THREE.Group();
marsGroup.add( mars );

marsGroup.rotation.x=1.5;

//jowisz sama planeta
const jupiterGeo = new THREE.SphereGeometry( 50, 64, 32 );
const jupiterMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_jupiter.jpg")} );
const jupiter = new THREE.Mesh( jupiterGeo, jupiterMat );

jupiter.castShadow = true;
jupiter.receiveShadow = true;

jupiter.position.x = 750;
//odleglosc od powierzchni slonca 550

//grupa z jowiszem
const jupiterGroup = new THREE.Group();
jupiterGroup.add( jupiter );

jupiterGroup.rotation.x=-1.1;


//saturn sama planeta
const satPlanGeo = new THREE.SphereGeometry( 40, 64, 32 );
const satPlanMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_saturn.jpg")} );
const satPlan = new THREE.Mesh( satPlanGeo, satPlanMat );

satPlan.castShadow = true;
satPlan.receiveShadow = true;


//pierscien saturna
const satRingGeo = new THREE.RingGeometry( 45, 70, 32 );
const satRingMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/ring2.png"), side: THREE.DoubleSide , transparent: true }  ); 
const satRing = new THREE.Mesh( satRingGeo, satRingMat );
satRing.rotation.x=1.57;
satRing.rotation.y=0.3;
//satRing.rotation.z=1.57;

satRing.castShadow = true;
satRing.receiveShadow = true;

//saturn razem z pierscieniem
const saturn = new THREE.Group();
saturn.add( satPlan );
saturn.add( satRing );
saturn.position.x = 1000;
//odleglosc od powierzchni slonca 700

//grupa z saturnem
const saturnGroup = new THREE.Group();
saturnGroup.add( saturn );

saturnGroup.rotation.x=+0.3;

//uran sama planeta
const uranPlanGeo = new THREE.SphereGeometry( 28, 64, 32 );
const uranPlanMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_uranus.jpg")} );
const uranPlan = new THREE.Mesh( uranPlanGeo, uranPlanMat );

uranPlan.castShadow = true;
uranPlan.receiveShadow = true;


//pierscien urana
const uranRingGeo = new THREE.RingGeometry( 30, 60, 32 );
const uranRingMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/uranusring.png"), side: THREE.DoubleSide , transparent: true }  ); 
const uranRing = new THREE.Mesh( uranRingGeo, uranRingMat );
uranRing.rotation.x=1.57;
uranRing.rotation.y=0.3;

uranRing.castShadow = true;
uranRing.receiveShadow = true;

//saturn razem z pierscieniem
const uranus = new THREE.Group();
uranus.add( uranPlan );
uranus.add( uranRing );
uranus.position.x = 1200;
//odleglosc od powierzchni slonca 850


//grupa z uranem
const uranusGroup = new THREE.Group();
uranusGroup.add( uranus );

uranusGroup.rotation.x=-2.1;

//neptun sama planeta
const neptuneGeo = new THREE.SphereGeometry( 24, 64, 32 );
const neptuneMat = new THREE.MeshStandardMaterial( { map: new THREE.TextureLoader().load("./img/2k_neptune.jpg")} );
const neptune = new THREE.Mesh( neptuneGeo, neptuneMat );

neptune.castShadow = true;
neptune.receiveShadow = true;

neptune.position.x = 1400;
//odleglosc od powierzchni slonca 950

//grupa z neptunem
const neptuneGroup = new THREE.Group();
neptuneGroup.add( neptune );

neptuneGroup.rotation.x=2.7;

const group = new THREE.Group();
group.add( sun );
group.add( mercuryGroup );
group.add( venusGroup );
group.add( earthMoonGroup );
group.add( marsGroup );
group.add( jupiterGroup );
group.add( saturnGroup );
group.add( uranusGroup );
group.add( neptune );


scene.add( group );


			
function animate() {

	requestAnimationFrame( animate );

	// required if controls.enableDamping or controls.autoRotate are set to true
	controls.update();

	renderer.render( scene, camera );
	//obroty wokol wlasnej osi
	//górna wartosc oszacowana
	//poczekac na tekstury i zobaczyc jak to wyglada
	sun.rotation.y+=0.001;
	sun.rotation.z+=0.001;
	
	mercury.rotation.y+=0.001;
	
	venus.rotation.y-=0.001;
	
	earth.rotation.y+=0.05;
	
	mars.rotation.y+=0.06;
	
	jupiter.rotation.y+=0.08;
	
	satPlan.rotation.y+=0.11;
	
	uranPlan.rotation.y+=0.07;
	
	neptune.rotation.y+=0.072;
	
	//obrót ksiezyca wokol ziemi
	earthMoon.rotation.y+=0.01;
	
	//obrót wokol słońca
	
	mercuryGroup.rotation.y+=0.04;
	
	venusGroup.rotation.y+=0.018;
	
	earthMoonGroup.rotation.y+=0.01;
	
	marsGroup.rotation.y+=0.006;
	
	jupiterGroup.rotation.y+=0.001;
	
	saturnGroup.rotation.y+=0.0003;
	
	uranusGroup.rotation.y+=0.00011;
	
	neptuneGroup.rotation.y+=0.0000061; 
	

}
animate();

